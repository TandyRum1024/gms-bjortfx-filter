______   ___  _   _______ _____________   __
| ___ \ |_  |(_)_(_) ___ \_   _|  ___\ \ / /
| |_/ /   | ||  _  | |_/ / | | | |_   \ V / 
| ___ \   | || | | |    /  | | |  _|  /   \ 
| |_/ /\__/ /\ \_/ / |\ \  | | | |   / /^\ \
\____/\____/  \___/\_| \_| \_/ \_|   \/   \/

ZIK PRESENTS : BJÖRTFX - A CRT-like retro screen effect utility

=[ Desc ]=
This was originally written for a tech demo of my latest shader (https://github.com/TandyRum1024/gms-bjortfx-filter) example.
Using this, you can create images with retro, old monitors aesthetics as if they've been captured from such monitors.
This program provides you with various controls to fiddle aroud while also allowing you to apply the effects on your own pictures, so feel free to go wild & experiment with the settings!
Also, this program allows you to resize the windows as much as you like it so there's that too.. Have fun!
Sincerely, ZIK @ MMXX